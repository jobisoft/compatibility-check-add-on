# compatibility-check-add-on
Add-on to check compatability of all installed add-ons with the current and next Thunderbird ESR, and Thunderbird Release.
